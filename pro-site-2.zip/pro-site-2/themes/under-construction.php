
<!-- USE  <"?"php include('themes/under-construction.php'); ?> -->


<body>
  <?php include('themes/nav.php'); ?>
    <main>
        <h1></h1>
        <div class="window" style="width: 250px" padding="10px">       
            <div class="title-bar">
                <div class="title-bar-text">under-construction.exe</div>
                    <div class="title-bar-controls">
                        <button aria-label="Minimize"></button>
                        <button aria-label="Maximize"></button>
                        <button aria-label="Close"></button>
                    </div>
                </div>
                <div class="window-body">
                    <p><b>
                        UNDER CONSTRUCTION
                        <br><br>
                        <img src="images/old-under-construction-gif.gif" alt="construction" width="150px" center>
                    </b></p>
                    <section class="field-row" style="justify-content: flex-end">
                        <a href="index.php"><button>Ok</button></a>
                    </section>
                </div>
            </div>
        </div>
    </main>
</body>

