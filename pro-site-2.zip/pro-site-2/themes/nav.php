

<!-- Use <"?"php include('themes/nav.php'); ?> -->

<aside>
        <ul class="tree-view">
          <li>GitHub Page</li>
          <li>
            <a href="index.php">Home</a>
            <ul>
              <li><a href="blog.php">Blog</a></li>
              <li><a href="work-exp.php">Work Experience</a></li>
              <li><a href="college.php">College</a></li>
              <li><a href="skills.php">Skills</a></li>
              <li>
                <a href="projects.php">Projects</a>
                <ul>
                  <li><a href="projects.php">Raspberry Pi Web Server</a></li>
                  <li><a href="projects.php">MIPS R3000</a></li>
                  <li><a href="projects.php">Java Pokergame</a></li>
                </ul>
              </li>
              <li><a href="volunteer.php">Volunteer</a></li>
              <li><a href="contact.php">Contact Info</a></li>
            </ul>
          </li>
        </ul>
    </aside>