<!DOCTYPE html>
<html lang="en">
  <head>
    <title>LDELATO | Blog</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="shortcut icon" href="images/frog-xp.jpg">
  
    <meta property="og:title" content="XP.css">
    <meta name="Description" content="A design system for building faithful recreations of old UIs.">
    <meta property="og:description" content="A design system for building faithful recreations of old UIs.">
    <meta property="og:image" content="https://github.com/botoxparty/XP.css/raw/main/docs/window.png?raw=true">
  
    <link id="theme-stylesheet" rel="stylesheet" href="https://botoxparty.github.io/XP.css/XP.css">
    <link rel="stylesheet" href="https://botoxparty.github.io/XP.css/docs.css">
    <link rel="stylesheet" href="https://botoxparty.github.io/XP.css/vs.css">
  </head>
  <?php include('themes/under-construction.php'); ?>
</html>
